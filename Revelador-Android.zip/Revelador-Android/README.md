# Revelador — APK Android

Este repositório contém a interface web do Revelador e um workflow do GitHub Actions que monta um aplicativo Android com WebView e gera `Revelador.apk`.

## Como compilar gratuitamente pelo GitHub

1. Crie um repositório no GitHub (público ou privado) e envie **todo o conteúdo desta pasta**, mantendo a estrutura:
   - `index.html`
   - `.github/workflows/apk.yml`
2. Abra a aba **Actions** do repositório e selecione **Gerar APK**.
3. Clique em **Run workflow** e confirme.
4. Quando terminar com sucesso, abra a execução e baixe o artefato **Revelador-APK**. Dentro dele estará `Revelador.apk`.

O workflow também tenta publicar uma release chamada `apk-latest`. Para isso funcionar, o token padrão do GitHub precisa ter permissão para criar releases; se a etapa falhar, o artefato do Actions ainda pode estar disponível.

## Observações

- O APK é um invólucro Android para o `index.html`; a geração de imagens depende da conexão e da disponibilidade dos serviços Stable Horde/Pollinations.
- O Pollinations pode exigir uma chave/API/saldo próprios, conforme as regras atuais do serviço.
- O workflow compila uma versão **debug** instalável para testes, não uma versão assinada para publicação na Play Store.
